create database my_models;

create table usuario (
id int auto_increment primary key,
nombre text,
correo text,
contraseña text
);

create table categoria (
id int auto_increment primary key,
nombre text,
descripcion text
);

create table modelo_3d (
id int auto_increment primary key,
nombre text,
descripcion text,
autor int,
archivo text,
categoria int,
descarga int,
foreign key (autor) references usuario(id) on delete cascade on update cascade,
foreign key (categoria) references categoria(id) on delete cascade on update cascade
);

create table descarga (
id int auto_increment primary key,
usuario int,
modelo int,
fecha timestamp default current_timestamp, 
foreign key (usuario) references usuarios(id) on delete cascade on update cascade,
foreign key (modelo) references modelo_3d(id) on delete cascade on update cascade
); 

alter table modelo_3d
add foreign key (descarga) references descarga(id) on delete cascade on update cascade;


insert into usuario (nombre, correo, contraseña)
values ('Juan Valdez','juanvaldez@hotmail.com','contra1')
values ('Julian Cepeda','juliancepeda@hotmail.com','contra2')
values ('Shawn Diaz','shawndiaz@hotmail.com','contra3')
values ('Carlos Henao','carloshenao@hotmail.com','contra4')
values ('Maria Cardenas','mariacardenas@hotmail.com','contra5')

insert into categoria (nombre, descripcion)
values ('casas','casas para decorar')
values ('animales','animales para decorar')
values ('cuadros','cuadros para decorar')
values ('comida','comida para decorar')
values ('personajes','personajes para decorar')

insert into models_3d (nombre, descripcion, autor, archivo, categoria, descarga)
values ('modelo cuadro','cuadro para decorar',1,'inicio/categoria/objetos/modelo_cuadro.obj',1,1)
values ('modelo perro','perro articulado',2,'inicio/categoria/animales/modelo_perro.stl',2,2)
values ('modelo jarron','jarron cristalizado',3,'inicio/objetos/jarron/modelo_jarron.obj',3,3)
values ('modelo arbol','arbol realista',4,'inicio/categoria/objetos/modelo_arbol.obj',4,4)
values ('modelo manzana','manzana verde',5,'inicio/categoria/comida/modelo_naranja.obj',5,5)

insert into descarga (usuario, modelo, fecha)
values (1,2 '2024/10/21 14:30')
values (5,1 '2024/10/21 14:30')
values (2,1 '2024/10/21 14:30')
values (3,4 '2024/10/21 14:30')
values (4,3 '2024/10/21 14:30')
